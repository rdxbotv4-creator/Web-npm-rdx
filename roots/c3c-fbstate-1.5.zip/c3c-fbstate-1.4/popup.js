// Copyright 2022 BadAimWeeb. All rights reserved. MIT license.

var stringToBlob = function (str, mimetype) {
    var raw = str;
    var rawLength = raw.length;
    var uInt8Array = new Uint8Array(rawLength);

    for (var i = 0; i < rawLength; ++i) {
        uInt8Array[i] = raw.charCodeAt(i);
    }

    var bb = new Blob([uInt8Array.buffer], {
        type: mimetype
    });
    return bb;
};

window.onload = function () {
    const terminalText = document.getElementById("terminal-text");
    const messages = [
        "Welcome to RDX C3C FB STATE...",
        "Appstate extracted successfully.",
        "Use this data in APPSTATE.JSON to login your bot.",
        "Paste it carefully into your configuration file.",
        "-----------------------------------------",
        "WARNING: Never leave Github Repository public!",
        "HACKING RISK DETECTED if shared publicly.",
        "Always keep your FBState private and secure."
    ];

    let msgIndex = 0;
    let charIndex = 0;

    function typeWriter() {
        if (msgIndex < messages.length) {
            if (charIndex < messages[msgIndex].length) {
                terminalText.innerHTML += messages[msgIndex].charAt(charIndex);
                charIndex++;
                setTimeout(typeWriter, 40);
            } else {
                terminalText.innerHTML += "\n";
                msgIndex++;
                charIndex = 0;
                setTimeout(typeWriter, 800);
            }
        }
    }

    typeWriter();

    function fetchUserInfo() {
        chrome.cookies.get({
            url: "https://www.facebook.com",
            name: "c_user"
        }, function(cookie) {
            const profileElement = document.getElementById("user-profile");
            const statusDot = document.getElementById("status-dot");
            
            if (cookie) {
                const uid = cookie.value;
                profileElement.style.display = "flex";
                statusDot.classList.add("online");
                document.getElementById("user-id").innerText = "ID: " + uid;
                document.getElementById("user-avatar").src = `https://graph.facebook.com/${uid}/picture?type=large`;
                
                // Improved name fetching using a more reliable Facebook mobile endpoint or profile page parsing
                fetch(`https://mbasic.facebook.com/profile.php`)
                    .then(response => response.text())
                    .then(html => {
                        // Look for the name in the title or specific tags in mbasic
                        const nameMatch = html.match(/<title>(.*?)<\/title>/);
                        if (nameMatch && nameMatch[1] && !nameMatch[1].includes("Facebook")) {
                            document.getElementById("user-name").innerText = nameMatch[1];
                        } else {
                            // Fallback: search for the name in the heading
                            const headerMatch = html.match(/<strong class="..">(.*?)<\/strong>/);
                            if (headerMatch && headerMatch[1]) {
                                document.getElementById("user-name").innerText = headerMatch[1];
                            } else {
                                document.getElementById("user-name").innerText = "Active User";
                            }
                        }
                    })
                    .catch(() => {
                        // Final fallback to graph if name is still missing
                        document.getElementById("user-name").innerText = "Active User";
                    });
            } else {
                profileElement.style.display = "flex";
                statusDot.classList.remove("online");
                document.getElementById("user-name").innerText = "Not Logged In";
                document.getElementById("user-id").innerText = "Please login to FB";
                document.getElementById("user-avatar").src = "https://cdn-icons-png.flaticon.com/512/149/149071.png";
            }
        });
    }

    fetchUserInfo();

    function toastNotification(message) {
        var x = document.getElementById("snackbar");
                                x.addEventListener("click", function() {
                                        x.className = x.className.replace("show", "");
                                });
        x.innerHTML = message;
        x.className = "show";
        setTimeout(function () {
                                                x.className = x.className.replace("show", "");
        }, 3000);
    }

    function importFunc(e, encrypted) {
        if (e.currentTarget.files[0]) {
            if (e.currentTarget.files[0].type != "application/json") {
                toastNotification("Invalid file given");
            }
            var fr = new FileReader();
            fr.readAsText(e.currentTarget.files[0], "UTF-8");
            fr.onload = function (evt) {
                try {
                    let data = evt.target.result;

                    if (encrypted) {
                        // Asking for key
                        const pwdKey = prompt("Please enter key to encrypt:");
                        const keyHash = [...sha256(pwdKey || "").match(/.{2}/g)].map(e => parseInt(e, 16));

                        const bytes = aesjs.utils.hex.toBytes(data);
                        const aesCtr = new aesjs.ModeOfOperation.ctr(keyHash);
                        const decryptedData = aesCtr.decrypt(bytes);

                        data = aesjs.utils.utf8.fromBytes(decryptedData);
                    }

                    var j = JSON.parse(data);
                    if (Array.isArray(j)) {
                        chrome.cookies.getAll({
                            domain: "facebook.com"
                        }, async function (cookies) {
                            for (let i in cookies) {
                                await new Promise(resolve => {
                                    chrome.cookies.remove({
                                        url: `https://facebook.com${cookies[i].path}`,
                                        name: cookies[i].name
                                    }, resolve);
                                });
                            }

                            for (let i in j) {
                                if (j[i].domain == "facebook.com") {
                                    await new Promise(resolve => {
                                        chrome.cookies.set({
                                            url: `https://facebook.com${j[i].path}`,
                                            name: j[i].key,
                                            value: j[i].value,
                                            expirationDate: (Date.now() / 1000) + (84600 * 30),
                                            domain: ".facebook.com"
                                        }, resolve);
                                    });
                                }
                            }
                            chrome.tabs.query({
                                active: true
                            }, function (tabs) {
                                var {
                                    host
                                } = new URL(tabs[0].url);
                                if (host.split(".")[1] == "facebook") {
                                    chrome.tabs.update(tabs[0].id, {
                                        url: tabs[0].url
                                    });
                                }
                            });
                        });
                    } else {
                        toastNotification("Invalid JSON file (not a FBState JSON file).");
                    }
                } catch (_) {
                    toastNotification("Failed to load JSON file (malformed?)");
                }
            }
        }
    }

    function exportFunc(encrypted) {
        chrome.cookies.getAll({
            domain: "facebook.com"
        }, function (cookies) {
            var cok = cookies.map(v => ({
                key: v.name,
                value: v.value,
                domain: "facebook.com",
                path: v.path,
                hostOnly: v.hostOnly,
                creation: new Date().toISOString(),
                lastAccessed: new Date().toISOString()
            }));
            var fbstate = JSON.stringify(cok, null, 4);

            if (encrypted) {
                // Asking for key
                let pwdKey = prompt("Please enter key to encrypt:");
                let keyHash = [...sha256(pwdKey || "").match(/.{2}/g)].map(e => parseInt(e, 16));

                let bytes = aesjs.utils.utf8.toBytes(fbstate);
                let aesCtr = new aesjs.ModeOfOperation.ctr(keyHash);
                let encryptedData = aesCtr.encrypt(bytes);
                fbstate = aesjs.utils.hex.fromBytes(encryptedData);
            }
            const yourFbstate = document.getElementById("yourFbstate");
            const btnCopy = document.getElementById("btnCopy");
            const btnDownload = document.getElementById("btnDownload");
            yourFbstate.value = fbstate;

            btnCopy.onclick = function () {
                yourFbstate.select();
                document.execCommand("copy");
                toastNotification('Success! The fbstate was copied to your clipboard');
            };

            btnDownload.onclick = function () {
                var blob = stringToBlob(fbstate, "application/json");
                var url = window.webkitURL || window.URL || window.mozURL || window.msURL;
                var a = document.createElement('a');
                a.download = 'fbstate_rdx.json';
                a.href = url.createObjectURL(blob);
                a.textContent = '';
                a.dataset.downloadurl = ['json', a.download, a.href].join(':');
                a.click();
                toastNotification('Success! RDX FBState downloaded: ' + a.download);
                a.remove();
            };
        });
    }

    function logout() {
        const result = confirm("Are you sure you want to logout?");
        if (result) {
            chrome.cookies.getAll({
                domain: "facebook.com"
            }, function (cookies) {
                // * it helps you not to lose the list of recently logged in accounts
                cookies = cookies.filter(c => c.name != "sb" && c.name != "dbln");

                for (let i in cookies) {
                    chrome.cookies.remove({
                        url: `https://facebook.com${cookies[i].path}`,
                        name: cookies[i].name
                    });
                }
                chrome.tabs.query({
                    active: true
                }, function (tabs) {
                    const {
                        host
                    } = new URL(tabs[0].url);
                    if (host.split(".")[1] == "facebook") {
                        chrome.tabs.update(tabs[0].id, {
                            url: tabs[0].url
                        });
                    }
                });
            });
        }
    }

    document.getElementById("import").onchange = (e) => importFunc(e, false);
    document.getElementById("importenc").onchange = (e) => importFunc(e, true);

    document.getElementById("export").onclick = () => exportFunc(false);
    document.getElementById("exportenc").onclick = () => exportFunc(true);
    document.getElementById("logout").onclick = () => logout();
    exportFunc(false);
};